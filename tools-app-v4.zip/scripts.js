document.querySelectorAll('nav button').forEach(btn => {
  btn.addEventListener('click', () => {
    fetch(btn.dataset.tool).then(res => res.text()).then(html => {
      const container = document.getElementById('tool-container');
      container.innerHTML = html;
    });
  });
});

const theme = localStorage.getItem('theme') || 'light';
document.body.classList.add(theme);
document.getElementById('theme-selector').value = theme;
document.getElementById('theme-selector').addEventListener('change', (e) => {
  document.body.className = e.target.value;
  localStorage.setItem('theme', e.target.value);
});